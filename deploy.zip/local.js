var index = require('./index');
(async () => {
	console.log(await index.handler())
})()